# Comp4332
1. Group Information
        Name: Chan Man Yee      Student ID: 20278380
        Name: Ko Man Ching      Student ID: 20028216
2. file list
        insertion.js
	query.js
        readme.txt
3. file description
        insertion.js is the script for inserting the data into database
	query.js is the script for extracting information from database
        readme.txt contains group information, file list, file description and known bugs of the system
4. known bugs of your system
        1.The Course Search By Keyword can only extract data with keyword “Risk Mining”, the result will always return COMP4332 and RMBI4310
        2. The Course Search By Waiting List Size do not have the attribute “Satisfied”
	3. The Course Search By Waiting List Size can only extract the data with start_ts = 2018-01-26T14:00:00Z and  end_ts = 2018-02-01T11:30:00Z, the result will always return COMP4332 and RMB4310.